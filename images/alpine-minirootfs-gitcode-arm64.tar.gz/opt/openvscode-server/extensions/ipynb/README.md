# Jupyter for Visual Studio Code

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

## Features

This extension provides the following Jupyter-related features for VS Code:

- Open, edit and save .ipynb files
